# ResiliPay AI — PayPal Hackathon MVP

A local multi-SACCO demo with a polished responsive dashboard, dark/light theme, currency selection, income shock simulation (up to 10,000,000 units), SACCO-scoped members, reporting date filters, and PayPal Sandbox checkout.

## Run on Windows
Backend terminal:
```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
# Add PayPal Sandbox credentials to backend\.env when ready
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```
Frontend terminal:
```powershell
cd frontend
npm install
npm run dev
```
Open the Vite URL (normally http://127.0.0.1:5173). API docs: http://127.0.0.1:8000/docs.

## PayPal
Create a Sandbox REST app at PayPal Developer and set `PAYPAL_CLIENT_ID` and `PAYPAL_CLIENT_SECRET` in `backend/.env`. Never put the secret in frontend code. The app creates and captures orders using PayPal's Sandbox API. The backend marks a payment complete only when PayPal's capture response says `COMPLETED`. Webhook signature verification is not included yet, so this is a hackathon prototype, not production payment infrastructure.

## Honest feature status
- Functional: deterministic simulator, SACCO registration, member registration/listing, payment records, date filters, theme switch.
- PayPal: functional when sandbox credentials are configured.
- M-Pesa: not integrated in this version; do not present it as live.
- Card entry: card funding may be offered by PayPal-hosted checkout according to sandbox account/country eligibility. ResiliPay never collects raw card numbers.
- Authentication/RBAC: UI includes role concepts, but production-grade login, verified identities, and tenant authorization are not yet implemented. Use fictional data only.
- The demo SACCO switch is not a security boundary. Production must derive tenant scope from a trusted server-side session.

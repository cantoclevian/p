from datetime import datetime, date, time, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional
import base64
import httpx
from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import create_engine, String, Integer, Numeric, DateTime, ForeignKey, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session

class Settings(BaseSettings):
    app_name: str = "ResiliPay AI"
    database_url: str = "sqlite:///./resilipay.db"
    frontend_url: str = "http://127.0.0.1:5173"
    paypal_client_id: str = ""
    paypal_client_secret: str = ""
    paypal_base_url: str = "https://api-m.sandbox.paypal.com"
    max_amount: Decimal = Decimal("10000000")
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

cfg = Settings()
engine = create_engine(cfg.database_url, connect_args={"check_same_thread": False} if cfg.database_url.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
class Base(DeclarativeBase): pass

class Sacco(Base):
    __tablename__="saccos"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    name: Mapped[str]=mapped_column(String(160),unique=True,index=True)
    country: Mapped[str]=mapped_column(String(100),default="Kenya")
    currency: Mapped[str]=mapped_column(String(3),default="KES")
    timezone: Mapped[str]=mapped_column(String(80),default="Africa/Nairobi")
class Member(Base):
    __tablename__="members"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    sacco_id: Mapped[int]=mapped_column(ForeignKey("saccos.id"),index=True)
    member_number: Mapped[str]=mapped_column(String(50))
    full_name: Mapped[str]=mapped_column(String(160))
    email: Mapped[str]=mapped_column(String(254),default="")
    country: Mapped[str]=mapped_column(String(100),default="Kenya")
    currency: Mapped[str]=mapped_column(String(3),default="KES")
    monthly_income: Mapped[Decimal]=mapped_column(Numeric(16,2),default=0)
class Payment(Base):
    __tablename__="payments"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    sacco_id: Mapped[int]=mapped_column(ForeignKey("saccos.id"),index=True)
    member_id: Mapped[Optional[int]]=mapped_column(ForeignKey("members.id"),nullable=True)
    provider: Mapped[str]=mapped_column(String(20),default="PAYPAL")
    order_id: Mapped[str]=mapped_column(String(120),index=True)
    amount: Mapped[Decimal]=mapped_column(Numeric(16,2))
    currency: Mapped[str]=mapped_column(String(3))
    status: Mapped[str]=mapped_column(String(30),default="CREATED")
    created_at: Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))

Base.metadata.create_all(engine)
def db_dep():
    db=SessionLocal()
    try: yield db
    finally: db.close()
app=FastAPI(title=cfg.app_name,version="0.3.0",description="ResiliPay AI hackathon demo API")
app.add_middleware(CORSMiddleware,allow_origins=[cfg.frontend_url,"http://localhost:5173"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

COUNTRIES=[
["Kenya","KES","Africa/Nairobi"],["Uganda","UGX","Africa/Kampala"],["Tanzania","TZS","Africa/Dar_es_Salaam"],["Rwanda","RWF","Africa/Kigali"],
["South Africa","ZAR","Africa/Johannesburg"],["Nigeria","NGN","Africa/Lagos"],["Ghana","GHS","Africa/Accra"],["United States","USD","America/New_York"],
["United Kingdom","GBP","Europe/London"],["Germany","EUR","Europe/Berlin"],["France","EUR","Europe/Paris"],["Canada","CAD","America/Toronto"],
["Australia","AUD","Australia/Sydney"],["India","INR","Asia/Kolkata"],["Japan","JPY","Asia/Tokyo"],["United Arab Emirates","AED","Asia/Dubai"],
["Singapore","SGD","Asia/Singapore"],["New Zealand","NZD","Pacific/Auckland"],["Switzerland","CHF","Europe/Zurich"],["China","CNY","Asia/Shanghai"],
["Brazil","BRL","America/Sao_Paulo"],["Mexico","MXN","America/Mexico_City"],["Philippines","PHP","Asia/Manila"],["Pakistan","PKR","Asia/Karachi"],
["Bangladesh","BDT","Asia/Dhaka"],["Sri Lanka","LKR","Asia/Colombo"],["Ethiopia","ETB","Africa/Addis_Ababa"],["Egypt","EGP","Africa/Cairo"],
["Morocco","MAD","Africa/Casablanca"],["Botswana","BWP","Africa/Gaborone"],["Zambia","ZMW","Africa/Lusaka"],["Namibia","NAD","Africa/Windhoek"]]
CURRENCIES=sorted(set([("KES","Kenyan Shilling"),("UGX","Ugandan Shilling"),("TZS","Tanzanian Shilling"),("RWF","Rwandan Franc"),("ZAR","South African Rand"),("NGN","Nigerian Naira"),("GHS","Ghanaian Cedi"),("USD","US Dollar"),("GBP","Pound Sterling"),("EUR","Euro"),("CAD","Canadian Dollar"),("AUD","Australian Dollar"),("INR","Indian Rupee"),("JPY","Japanese Yen"),("AED","UAE Dirham"),("SGD","Singapore Dollar"),("NZD","New Zealand Dollar"),("CHF","Swiss Franc"),("CNY","Chinese Yuan"),("BRL","Brazilian Real"),("MXN","Mexican Peso"),("PHP","Philippine Peso"),("PKR","Pakistani Rupee"),("BDT","Bangladeshi Taka"),("LKR","Sri Lankan Rupee"),("ETB","Ethiopian Birr"),("XOF","West African CFA Franc"),("XAF","Central African CFA Franc"),("SEK","Swedish Krona"),("NOK","Norwegian Krone"),("DKK","Danish Krone"),("PLN","Polish Zloty"),("TRY","Turkish Lira"),("SAR","Saudi Riyal"),("QAR","Qatari Riyal"),("ILS","Israeli New Shekel"),("THB","Thai Baht"),("IDR","Indonesian Rupiah"),("MYR","Malaysian Ringgit"),("KRW","South Korean Won"),("HKD","Hong Kong Dollar"),("TWD","New Taiwan Dollar"),("ARS","Argentine Peso"),("CLP","Chilean Peso"),("COP","Colombian Peso"),("PEN","Peruvian Sol"),("EGP","Egyptian Pound"),("MAD","Moroccan Dirham"),("BWP","Botswana Pula"),("ZMW","Zambian Kwacha"),("MUR","Mauritian Rupee"),("NAD","Namibian Dollar")]))
def money(v): return str(Decimal(v).quantize(Decimal("0.01"),rounding=ROUND_HALF_UP))
def seed():
    with SessionLocal() as db:
        if not db.scalar(select(Sacco.id).limit(1)):
            db.add_all([Sacco(name="Weke Community SACCO",country="Kenya",currency="KES",timezone="Africa/Nairobi"),
                        Sacco(name="Umoja Cooperative (Demo)",country="Uganda",currency="UGX",timezone="Africa/Kampala"),
                        Sacco(name="Global Community Credit Union (Demo)",country="United States",currency="USD",timezone="America/New_York")]); db.commit()
        if not db.scalar(select(Member.id).limit(1)):
            for s in db.scalars(select(Sacco)).all():
                for num,name,income in [("001","Amina Otieno",200000),("002","Daniel Mwangi",145000),("003","Grace Wanjiku",98000)]:
                    db.add(Member(sacco_id=s.id,member_number=f"{s.id}-MEM-{num}",full_name=name,email=f"{num}@example.test",country=s.country,currency=s.currency,monthly_income=income))
            db.commit()
seed()

class SimInput(BaseModel):
    income: Decimal=Field(ge=0,le=Decimal("10000000"))
    expenses: Decimal=Field(ge=0,le=Decimal("10000000"))
    repayment: Decimal=Field(ge=0,le=Decimal("10000000"))
    income_reduction_pct: Decimal=Field(ge=0,le=100)
    unexpected_expense: Decimal=Field(ge=0,le=Decimal("10000000"))
    currency: str=Field(min_length=3,max_length=3)
class SaccoInput(BaseModel):
    name: str=Field(min_length=2,max_length=160)
    country: str
    currency: str=Field(min_length=3,max_length=3)
    timezone: str="UTC"
class MemberInput(BaseModel):
    sacco_id: int
    member_number: str=Field(min_length=1,max_length=50)
    full_name: str=Field(min_length=2,max_length=160)
    email: str=""
    country: str="Kenya"
    currency: str="KES"
    monthly_income: Decimal=Field(ge=0,le=Decimal("10000000"))
class OrderInput(BaseModel):
    sacco_id: int
    member_id: Optional[int]=None
    amount: Decimal=Field(gt=0,le=Decimal("10000000"))
    currency: str=Field(min_length=3,max_length=3)
class CaptureInput(BaseModel):
    order_id: str
    sacco_id: int

@app.get("/api/health")
def health(): return {"status":"ok","paypal_configured":bool(cfg.paypal_client_id and cfg.paypal_client_secret)}
@app.get("/api/meta")
def meta(): return {"countries":[{"name":c[0],"currency":c[1],"timezone":c[2]} for c in COUNTRIES],
                    "currencies":[{"code":c,"name":n} for c,n in CURRENCIES],"max_amount":"10000000"}
@app.get("/api/saccos")
def list_saccos(db:Session=Depends(db_dep)):
    return [{"id":s.id,"name":s.name,"country":s.country,"currency":s.currency,"timezone":s.timezone} for s in db.scalars(select(Sacco).order_by(Sacco.name)).all()]
@app.post("/api/saccos")
def add_sacco(p:SaccoInput,db:Session=Depends(db_dep)):
    if db.scalar(select(Sacco).where(Sacco.name==p.name)): raise HTTPException(409,"SACCO name already exists")
    s=Sacco(**p.model_dump());db.add(s);db.commit();db.refresh(s)
    return {"id":s.id,"name":s.name,"country":s.country,"currency":s.currency,"timezone":s.timezone}
@app.get("/api/members")
def list_members(sacco_id:int=Query(...,gt=0),q:str="",db:Session=Depends(db_dep)):
    stmt=select(Member).where(Member.sacco_id==sacco_id)
    if q.strip(): stmt=stmt.where(Member.full_name.ilike(f"%{q.strip()}%"))
    return [{"id":m.id,"sacco_id":m.sacco_id,"member_number":m.member_number,"full_name":m.full_name,"email":m.email,"country":m.country,"currency":m.currency,"monthly_income":money(m.monthly_income)} for m in db.scalars(stmt.order_by(Member.full_name)).all()]
@app.post("/api/members")
def add_member(p:MemberInput,db:Session=Depends(db_dep)):
    if not db.get(Sacco,p.sacco_id): raise HTTPException(404,"SACCO not found")
    if db.scalar(select(Member).where(Member.sacco_id==p.sacco_id,Member.member_number==p.member_number)): raise HTTPException(409,"Member number already exists in this SACCO")
    m=Member(**p.model_dump());db.add(m);db.commit();db.refresh(m)
    return {"id":m.id,"sacco_id":m.sacco_id,"member_number":m.member_number,"full_name":m.full_name,"email":m.email,"country":m.country,"currency":m.currency,"monthly_income":money(m.monthly_income)}
@app.post("/api/simulate")
def simulate(p:SimInput):
    shocked=p.income*(1-p.income_reduction_pct/100)
    remain=shocked-p.expenses-p.repayment-p.unexpected_expense
    return {"currency":p.currency.upper(),"baseline_remaining":money(p.income-p.expenses-p.repayment),"shocked_income":money(shocked),"remaining_cash":money(remain),"status":"positive" if remain>=0 else "shortfall"}
async def paypal_token():
    if not cfg.paypal_client_id or not cfg.paypal_client_secret: raise HTTPException(503,"PayPal Sandbox is not configured. Add credentials to backend/.env")
    basic=base64.b64encode(f"{cfg.paypal_client_id}:{cfg.paypal_client_secret}".encode()).decode()
    async with httpx.AsyncClient(timeout=25) as c:
        r=await c.post(cfg.paypal_base_url+"/v1/oauth2/token",headers={"Authorization":f"Basic {basic}","Content-Type":"application/x-www-form-urlencoded"},data={"grant_type":"client_credentials"})
    if r.status_code>=400: raise HTTPException(502,"PayPal authentication failed; verify Sandbox credentials")
    return r.json()["access_token"]
@app.post("/api/paypal/orders")
async def paypal_order(p:OrderInput,db:Session=Depends(db_dep)):
    s=db.get(Sacco,p.sacco_id)
    if not s: raise HTTPException(404,"SACCO not found")
    if p.member_id:
        m=db.get(Member,p.member_id)
        if not m or m.sacco_id!=s.id: raise HTTPException(404,"Member not found in this SACCO")
    token=await paypal_token()
    body={"intent":"CAPTURE","purchase_units":[{"description":"ResiliPay AI demo repayment","custom_id":f"sacco:{s.id};member:{p.member_id or 0}","amount":{"currency_code":p.currency.upper(),"value":money(p.amount)}}],
          "application_context":{"brand_name":"ResiliPay AI","user_action":"PAY_NOW","return_url":cfg.frontend_url+"/?paypal=return","cancel_url":cfg.frontend_url+"/?paypal=cancel"}}
    async with httpx.AsyncClient(timeout=30) as c:
        r=await c.post(cfg.paypal_base_url+"/v2/checkout/orders",json=body,headers={"Authorization":f"Bearer {token}","Content-Type":"application/json"})
    if r.status_code>=400: raise HTTPException(502,"PayPal order creation failed. Check currency and Sandbox configuration.")
    data=r.json();db.add(Payment(sacco_id=s.id,member_id=p.member_id,order_id=data["id"],amount=p.amount,currency=p.currency.upper(),status="CREATED"));db.commit()
    return {"order_id":data["id"],"approval_url":next((x["href"] for x in data.get("links",[]) if x.get("rel")=="approve"),None),"status":data.get("status")}
@app.post("/api/paypal/capture")
async def paypal_capture(p:CaptureInput,db:Session=Depends(db_dep)):
    pay=db.scalar(select(Payment).where(Payment.order_id==p.order_id,Payment.sacco_id==p.sacco_id))
    if not pay: raise HTTPException(404,"Order not found for this SACCO")
    if pay.status=="COMPLETED": return {"status":"COMPLETED","order_id":pay.order_id}
    token=await paypal_token()
    async with httpx.AsyncClient(timeout=30) as c:
        r=await c.post(f"{cfg.paypal_base_url}/v2/checkout/orders/{p.order_id}/capture",headers={"Authorization":f"Bearer {token}","Content-Type":"application/json"})
    if r.status_code>=400: raise HTTPException(502,"PayPal capture failed; order may not be approved or capturable")
    data=r.json()
    if data.get("status")!="COMPLETED": raise HTTPException(409,f"PayPal status was {data.get('status')}, not COMPLETED")
    pay.status="COMPLETED";db.commit()
    return {"status":"COMPLETED","order_id":pay.order_id,"message":"Capture status confirmed by PayPal backend response"}
@app.get("/api/payments")
def list_payments(sacco_id:int=Query(...,gt=0),start_date:Optional[date]=None,end_date:Optional[date]=None,db:Session=Depends(db_dep)):
    stmt=select(Payment).where(Payment.sacco_id==sacco_id)
    if start_date: stmt=stmt.where(Payment.created_at>=datetime.combine(start_date,time.min))
    if end_date: stmt=stmt.where(Payment.created_at<datetime.combine(end_date,time.max))
    return [{"id":p.id,"member_id":p.member_id,"provider":"PAYPAL","order_id":p.order_id,"amount":money(p.amount),"currency":p.currency,"status":p.status,"created_at":p.created_at.isoformat()} for p in db.scalars(stmt.order_by(Payment.created_at.desc())).all()]
